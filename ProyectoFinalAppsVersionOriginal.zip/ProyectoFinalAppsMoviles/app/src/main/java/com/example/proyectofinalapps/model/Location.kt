package com.example.proyectofinalapps.model

class Location(
    var latitud: Double,
    var longitud: Double
) {
}