package com.example.proyectofinalapps.model

class Client(
    var telefono: String,
    var genero: Genero
) {
}