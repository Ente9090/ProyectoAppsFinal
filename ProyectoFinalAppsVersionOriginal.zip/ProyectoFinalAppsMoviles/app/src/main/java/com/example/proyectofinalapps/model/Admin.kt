package com.example.proyectofinalapps.model

class Admin(
    var salario: Double,
) {
}