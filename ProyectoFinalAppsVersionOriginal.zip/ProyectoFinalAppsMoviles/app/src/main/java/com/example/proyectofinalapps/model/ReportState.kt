package com.example.proyectofinalapps.model

enum class ReportState{
    PENDIENTE,
    EN_PROCESO,
    RESUELTO,
    RECHAZADO

}