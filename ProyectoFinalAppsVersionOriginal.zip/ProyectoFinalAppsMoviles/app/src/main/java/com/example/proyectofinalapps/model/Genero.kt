package com.example.proyectofinalapps.model

enum class Genero {
    MASCULINO,
    FEMENINO,
    OTRO
}