package com.example.proyectofinalapps.model

enum class Role{
    ClIENTE,
    ADMINISTRADOR
}